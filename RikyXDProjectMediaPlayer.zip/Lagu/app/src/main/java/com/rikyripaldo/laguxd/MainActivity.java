package com.rikyripaldo.laguxd;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;

/*
  @author: Riky Ripaldo
  @contact : +6285789116608
*/

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        RequestsPermission();
        listView = findViewById(R.id.listview);
        seekBar = findViewById(R.id.seekbar);
        startTime = findViewById(R.id.startTime);
        finalTime = findViewById(R.id.finalTime);
        
        play = findViewById(R.id.play);
        back = findViewById(R.id.back);
        next = findViewById(R.id.next);
        prev = findViewById(R.id.prev);
        forw = findViewById(R.id.forw);
        
        final ArrayList<File> Lagu = cariLagu(Environment.getExternalStorageDirectory());
        lagu = new String[Lagu.size()];
        
        for (int i=0;i<Lagu.size();i++){
            lagu[i] = Lagu.get(i).getName().toString().replace(".mp3"," - Riky Ripaldo MP3").replace(".wav"," - Riky Ripaldo WAV");
        }        
        
        RikyAdapter adapter = new RikyAdapter();
        listView.setAdapter(adapter);
        
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id){
                if (mp != null){
                    mp.stop();
                    mp.release();
                }
                
                Uri uri = Uri.parse(Lagu.get(pos).toString());
                mp = MediaPlayer.create(getApplicationContext(), uri);
                String name = Lagu.get(pos).getName();
                Toast.makeText(getApplicationContext(), name.toString(), Toast.LENGTH_SHORT).show();
                play.setBackgroundResource(R.drawable.riky_ripaldo_pause);
                
                mp.start();
                
                Thread Update = new Thread(){
                    @Override
                    public void run(){
                        int time = mp.getDuration();
                        int pos = 0;
                        
                        while (pos<time){
                            try {
                                sleep(500);
                                pos = mp.getCurrentPosition();
                                seekBar.setProgress(pos);
                            }
                            catch (InterruptedException | IllegalAccessError ex){
                                Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                };
                
                mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        next.performClick();
                    }
                });
                
                next.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        if (mp != null){
                            mp.stop();
                            mp.release();
                        }
                        position = ((position+1)%Lagu.size());
                        Uri url = Uri.parse(Lagu.get(position).toString());
                        mp = MediaPlayer.create(getApplicationContext(), url);
                        String name = Lagu.get(position).getName();
                        Toast.makeText(getApplicationContext(), name.toString(), Toast.LENGTH_SHORT).show();
                        mp.start();
                    }
                });
                
                back.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        if (mp != null){
                            mp.stop();
                            mp.release();
                        }
                        position = ((position-1)<0)?(Lagu.size()-1):(position-1);
                        Uri uri = Uri.parse(Lagu.get(position).toString());
                        mp = MediaPlayer.create(getApplicationContext(), uri);
                        String name = Lagu.get(position).getName();
                        Toast.makeText(getApplicationContext(), name.toString(), Toast.LENGTH_SHORT).show();
                        mp.start();
                    }
                });
                
                seekBar.setMax(mp.getDuration());
                Update.start();
                seekBar.getProgressDrawable().setColorFilter(getResources().getColor(R.color.rikyxd), PorterDuff.Mode.SRC_IN);
                seekBar.getThumb().setColorFilter(getResources().getColor(R.color.seekBar), PorterDuff.Mode.SRC_IN);
                
                seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int i, boolean b){
                    }
                    public void onStartTrackingTouch(SeekBar seekBar){                      
                    }
                    public void onStopTrackingTouch(SeekBar seekBar){
                        try {
                            mp.seekTo(seekBar.getProgress());
                        }
                        catch (Exception e){
                            Toast.makeText(getApplicationContext(), R.string.tidak_memutar, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                
                prev.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                       if (mp.isPlaying()){
                           mp.seekTo(mp.getCurrentPosition()-10000);
                       }
                    }
                });
                
                forw.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        if (mp.isPlaying()){
                            mp.seekTo(mp.getCurrentPosition()+10000);
                        }
                    }
                });
                
                String endTime = Time(mp.getDuration());
                finalTime.setText(endTime);

                final Handler handler = new Handler();
                final int delay = 1000;

                handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            String Time = Time(mp.getCurrentPosition());
                            startTime.setText(Time);
                            handler.postDelayed(this, delay);
                        }
                    }, delay);
            }
        });
        
        play.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                try {
                    if (mp.isPlaying()){
                        mp.pause();
                        Toast.makeText(getApplicationContext(), R.string.musik_distop, Toast.LENGTH_SHORT).show();
                        play.setBackgroundResource(R.drawable.riky_ripaldo_play);
                    }
                   else {
                        mp.start();
                        Toast.makeText(getApplicationContext(), R.string.musik_diputar, Toast.LENGTH_SHORT).show();
                        play.setBackgroundResource(R.drawable.riky_ripaldo_pause);
                   }
                }
                catch (Exception ex){
                    Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    
    public void RequestsPermission(){
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MODE_PRIVATE);
            Toast.makeText(getApplicationContext(), R.string.izin_diterima, Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(getApplicationContext(), R.string.author_name, Toast.LENGTH_LONG).show();
        }
    }
    
    public ArrayList<File> cariLagu(File root){
        ArrayList<File> arrayList = new ArrayList<>();
        File[] files = root.listFiles();
        
        for (File selfFile: files){
            if (selfFile.isDirectory() && !selfFile.isHidden()){
                arrayList.addAll(cariLagu(selfFile));
            }
            else {
                if (selfFile.getName().endsWith(".mp3") || selfFile.getName().endsWith(".wav")){
                    arrayList.add(selfFile);
                }
            }
        }
        return arrayList;
    }

    @Override
    protected void onDestroy()
    {
        if (mp != null){
            mp.release();
        }
        super.onDestroy();
    }
    
    public String Time(int duration){
        String time = "";
        int min = duration/1000/60;
        int sec = duration/1000%60;

        time+=min+":";

        if (sec<10){
            time+="0";
        }
        time+=sec;
        return time;
    }
    
    private MediaPlayer mp;
    private ListView listView;
    private String[] lagu;
    private SeekBar seekBar;
    private int position;
    private Button prev, back, play, next, forw;
    private TextView startTime, finalTime;
    
    class RikyAdapter extends BaseAdapter
    {
        @Override
        public int getCount(){
            return lagu.length;
        }

        @Override
        public Object getItem(int i){
            return null;
        }

        @Override
        public long getItemId(int i)
        {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup)
        {
            view = getLayoutInflater().inflate(R.layout.riky_listview, null);
            TextView teksJudul = view.findViewById(R.id.judulLagu);
            teksJudul.setSelected(true);
            teksJudul.setText(lagu[i]);
            return view;
        }       
    }
}
